package com.example.parcial2;

public class Constants {
    public static final String TABLE_NAME_MATERIAS = "materias";
    public static final String DB_NAME = "materiasdb.db";
}